.. automodule:: NagAconda
   :platform: Unix
   :synopsis: Creates a loose framework to produce Nagios plugins
.. moduleauthor:: Shaun Thomas <sthomas@leapfrogonline.com>


